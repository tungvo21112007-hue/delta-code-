/**
 * codes-store.js - Kho giftcode: lưu trữ + phân loại trạng thái (Mới / Đã dùng / Hết hạn)
 *
 * Dùng chung ở 2 nơi (cùng một file, không cần bundler - chuẩn Manifest V3):
 *   - background.js : importScripts('codes-store.js')  -> NƠI DUY NHẤT GHI vào kho
 *   - popup.html    : <script src="codes-store.js">     -> chỉ ĐỌC / lọc / đếm để hiển thị
 *
 * ---------- Cách lưu trong chrome.storage.local ----------
 * Khoá  "dfCodes"  = một object, mỗi giftcode một mục, khoá là code viết thường:
 *   {
 *     "dfessence982": {
 *       code:      "DFessence982",   // dạng gốc để hiển thị
 *       status:    "new",            // "new" (Mới) | "used" (Đã sử dụng) | "expired" (Hết hạn)
 *       source:    "scan",           // "scan" (tự tìm) | "page" (Lưu nhanh từ trang) | "manual" (nhập tay)
 *       site:      "tomko.com.vn",   // trang phát hiện (nếu có)
 *       addedAt:   1760000000000,    // lúc thêm vào kho
 *       updatedAt: 1760000500000,    // lần đổi trạng thái / có kết quả gần nhất
 *       note:      "Code đã hết hạn" // thông báo gần nhất của trang khi thử nhập (cắt ngắn)
 *     }
 *   }
 * Gom tất cả vào MỘT khoá để mỗi lần đọc/ghi chỉ tốn 1 lệnh storage.
 * Giới hạn MAX_ENTRIES mục: vượt quá thì xoá bớt mục cũ nhất, ưu tiên Hết hạn -> Đã dùng -> Mới.
 *
 * ---------- Quy tắc phân loại tự động khi nhập code (xem classifyResult) ----------
 *   Nhập thành công                       -> "used"    (code đã bị bạn dùng)
 *   Trang báo "đã được sử dụng"/"already" -> "used"
 *   Trang báo "hết hạn"/"expired"         -> "expired"
 *   Lỗi khác (sai code, nút bị khoá...)   -> GIỮ NGUYÊN trạng thái, chỉ cập nhật "note"
 *   Code mới được thêm luôn bắt đầu là    -> "new"
 * Trạng thái không bao giờ bị tự hạ về "new"; muốn đổi tay thì dùng Kho code trong popup.
 *
 * ---------- Nhập (import) dữ liệu từ file: quy tắc GỘP (xem mergeEntries) ----------
 *   Code chưa có trong kho            -> thêm vào (giữ trạng thái/thời gian trong file nếu có)
 *   Code đã có + file có "updatedAt"   -> bản nào cập nhật SAU hơn thì thắng (trạng thái + ghi chú)
 *   Code đã có + file KHÔNG có thời gian (vd: danh sách chữ thường) -> giữ nguyên kho, không bị reset về "new"
 *   addedAt luôn lấy mốc sớm nhất; site chỉ được điền nếu kho đang để trống.
 */
const DfCodes = (() => {
  'use strict';

  const STORAGE_KEY = 'dfCodes';
  const STATUSES = ['new', 'used', 'expired'];
  const SOURCES = ['scan', 'page', 'manual'];
  const MAX_ENTRIES = 3000;
  const CODE_RE = /^[A-Za-z0-9_-]{4,64}$/; // Chỉ nhận chuỗi giống code, tránh ghi dữ liệu rác vào kho

  // Từ khoá trong thông báo của trang (không phân biệt hoa/thường). Hết hạn được kiểm tra trước.
  const EXPIRED_RE = /hết hạn|hết hiệu lực|expired|expire/i;
  const USED_RE = /đã (được )?sử dụng|đã dùng|đã nhận|already (been )?(used|redeemed|claimed)|has been (used|redeemed)/i;

  const keyOf = (code) => code.toLowerCase();
  const isValid = (code) => typeof code === 'string' && CODE_RE.test(code);

  /**
   * Từ kết quả nhập code (status: success | fail | unknown) + nội dung thông báo của trang
   * suy ra trạng thái mới của code. Trả về null nếu không đủ căn cứ (giữ nguyên trạng thái).
   */
  function classifyResult(status, note) {
    if (status === 'success') return 'used';
    if (status === 'fail') {
      const text = String(note || '');
      if (EXPIRED_RE.test(text)) return 'expired';
      if (USED_RE.test(text)) return 'used';
    }
    return null;
  }

  /** Thêm code mới (trạng thái "new"). Code đã có trong kho thì bỏ qua, không bao giờ ghi đè. */
  function addEntries(map, entries, now = Date.now()) {
    let added = 0;
    let existing = 0;
    for (const entry of entries) {
      const code = typeof entry?.code === 'string' ? entry.code.trim() : '';
      if (!isValid(code)) continue;
      const key = keyOf(code);
      if (map[key]) { existing += 1; continue; }
      map[key] = {
        code,
        status: 'new',
        source: SOURCES.includes(entry.source) ? entry.source : 'manual',
        site: entry.site ? String(entry.site).slice(0, 60) : '',
        addedAt: now,
        updatedAt: now,
        note: '',
      };
      added += 1;
    }
    return { added, existing };
  }

  /** Ghi nhận kết quả nhập một code: tự phân loại + lưu thông báo. Code chưa có trong kho sẽ được tạo. */
  function recordResult(map, code, resultStatus, note, now = Date.now()) {
    if (!isValid(code)) return null;
    addEntries(map, [{ code, source: 'manual' }], now); // Không làm gì nếu đã có
    const entry = map[keyOf(code)];
    const next = classifyResult(resultStatus, note);
    if (next) entry.status = next;
    entry.note = String(note || '').slice(0, 160);
    entry.updatedAt = now;
    return entry.status;
  }

  /** Đổi tay trạng thái cho nhiều code. Trả về số code đã đổi. */
  function setStatus(map, codes, status, now = Date.now()) {
    if (!STATUSES.includes(status)) return 0;
    let changed = 0;
    for (const code of codes) {
      const entry = typeof code === 'string' ? map[keyOf(code)] : null;
      if (!entry || entry.status === status) continue;
      entry.status = status;
      entry.updatedAt = now;
      changed += 1;
    }
    return changed;
  }

  /** Xoá code khỏi kho. Trả về số mục đã xoá. */
  function remove(map, codes) {
    let removed = 0;
    for (const code of codes) {
      const key = typeof code === 'string' ? keyOf(code) : '';
      if (key && map[key]) { delete map[key]; removed += 1; }
    }
    return removed;
  }

  // Tên trạng thái người dùng có thể gõ trong file CSV (kể cả nhãn tiếng Việt) -> giá trị chuẩn
  const STATUS_ALIASES = {
    new: 'new', 'mới': 'new', moi: 'new',
    used: 'used', 'đã dùng': 'used', 'da dung': 'used', 'đã sử dụng': 'used', 'da su dung': 'used',
    expired: 'expired', 'hết hạn': 'expired', 'het han': 'expired',
  };
  const parseStatus = (value) => STATUS_ALIASES[String(value ?? '').trim().toLowerCase()] || null;

  /** Đọc thời gian từ file: số (mili-giây hoặc giây) hoặc chuỗi ngày (ISO...). Không đọc được -> null */
  function parseTime(value) {
    if (value === null || value === undefined || value === '') return null;
    const n = Number(value);
    if (Number.isFinite(n) && n > 1e9) return n < 1e12 ? n * 1000 : n;
    const t = Date.parse(String(value));
    return Number.isFinite(t) ? t : null;
  }

  /** Làm sạch một dòng dữ liệu đọc từ file (không tin dữ liệu bên ngoài). Sai định dạng -> null */
  function normalizeImported(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const code = typeof raw.code === 'string' ? raw.code.trim() : '';
    if (!isValid(code)) return null;
    return {
      code,
      status: parseStatus(raw.status) || 'new',
      source: SOURCES.includes(raw.source) ? raw.source : 'manual',
      site: raw.site ? String(raw.site).slice(0, 60) : '',
      addedAt: parseTime(raw.addedAt),     // null = file không có thông tin này
      updatedAt: parseTime(raw.updatedAt),
      note: String(raw.note || '').slice(0, 160),
    };
  }

  /** Gộp dữ liệu nhập từ file vào kho (quy tắc ở đầu file). Trả về { added, updated, unchanged, invalid } */
  function mergeEntries(map, entries, now = Date.now()) {
    const result = { added: 0, updated: 0, unchanged: 0, invalid: 0 };
    for (const raw of entries) {
      const entry = normalizeImported(raw);
      if (!entry) { result.invalid += 1; continue; }

      const key = keyOf(entry.code);
      const current = map[key];

      if (!current) { // Code mới hoàn toàn -> thêm
        const addedAt = entry.addedAt ?? now;
        map[key] = { code: entry.code, status: entry.status, source: entry.source, site: entry.site, addedAt, updatedAt: entry.updatedAt ?? addedAt, note: entry.note };
        result.added += 1;
        continue;
      }

      // Code đã có -> bản cập nhật sau hơn thì thắng
      let changed = false;
      if (entry.updatedAt !== null && entry.updatedAt > current.updatedAt) {
        changed = current.status !== entry.status;
        current.status = entry.status;
        current.updatedAt = entry.updatedAt;
        if (entry.note) current.note = entry.note;
      }
      if (entry.addedAt !== null && entry.addedAt < current.addedAt) current.addedAt = entry.addedAt;
      if (!current.site && entry.site) current.site = entry.site;
      if (changed) result.updated += 1; else result.unchanged += 1;
    }
    return result;
  }

  /** Giữ kho không vượt MAX_ENTRIES: bỏ mục cũ nhất, Hết hạn trước, rồi Đã dùng, cuối cùng mới tới Mới */
  function prune(map) {
    const keys = Object.keys(map);
    if (keys.length <= MAX_ENTRIES) return 0;
    const rank = { expired: 0, used: 1, new: 2 };
    keys.sort((a, b) => (rank[map[a].status] - rank[map[b].status]) || (map[a].updatedAt - map[b].updatedAt));
    const drop = keys.slice(0, keys.length - MAX_ENTRIES);
    drop.forEach((key) => delete map[key]);
    return drop.length;
  }

  /** Đếm số code theo từng trạng thái */
  function counts(map) {
    const result = { new: 0, used: 0, expired: 0 };
    for (const entry of Object.values(map || {})) {
      if (result[entry.status] !== undefined) result[entry.status] += 1;
    }
    return result;
  }

  /** Danh sách code theo trạng thái (null = tất cả), mới cập nhật nhất lên đầu */
  function list(map, status = null) {
    return Object.values(map || {})
      .filter((entry) => !status || entry.status === status)
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }

  return { STORAGE_KEY, STATUSES, SOURCES, isValid, classifyResult, addEntries, recordResult, setStatus, remove, prune, counts, list, mergeEntries };
})();

// Cho phép chạy thử bằng Node; trong trình duyệt biến module không tồn tại nên dòng này bị bỏ qua
if (typeof module !== 'undefined') module.exports = DfCodes;
